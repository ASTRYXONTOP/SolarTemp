﻿using GorillaNetworking;
using Photon.Pun;
using PlayFab;
using System.Text.RegularExpressions;
using static StupidTemplate.Menu.Main;
using Object = UnityEngine.Object;
using UnityEngine;
using StupidTemplate.Menu;
using System.Collections.Generic;
using System.Linq;
using System;
using StupidTemplate.Notifications;
using StupidTemplate.Menu;
using Menuer;
using GorillaLocomotion.Gameplay;

namespace StupidTemplate.Mods
{
    internal class Global
    {
     
    }
}
