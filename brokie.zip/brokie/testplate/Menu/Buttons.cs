﻿using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;
using static StupidTemplate.Mods.Global;
using UnityEngine;
using GorillaNetworking;


namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
             
        };
    }
}
